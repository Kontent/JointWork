<?php
/**
* JointWork - The Joomla Project Manager
* @package JointWork.Template.Default
* @subpackage Tasks
* @copyright (C) 2011 Kontent Design. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://extensions.kontentdesign.com
*/
defined ( '_JEXEC' ) or die ();
